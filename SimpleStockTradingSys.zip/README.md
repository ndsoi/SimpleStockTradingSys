# SimpleStockTradingSys
web course project
